<!-- ---
layout: page
title: Example Submenu
nav: true
dropdown: true
children:
    - title: publications
      permalink: /publications/
    - title: divider
    - title: projects
      permalink: /projects/
--- -->
